#!/usr/bin/env python3
"""
storygen.py — daily Instagram STORIES for the Advanced Occult Astrology app.
Each story = one app screenshot inside a phone card + a Hindi headline + a link-bio CTA.

Usage:
  python3 storygen.py [--date 2026-11-07] [--outdir /scratch/work/stories] [--count 3]
"""
import argparse
import json
import math
import os
import random
from datetime import datetime, timezone, timedelta

from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 1080, 1920
HERE = os.path.dirname(os.path.abspath(__file__))
SHOTS = os.environ.get("SHOTS", "/scratch/work/screens")

FONT_B = "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Bold.ttf"
FONT_R = "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Regular.ttf"
FONT_LAT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

BG1 = (251, 243, 230)      # cream
BG2 = (226, 199, 162)      # warm tan
BROWN = (74, 36, 20)
GOLD = (166, 116, 32)
DEEP = (46, 22, 12)

# key -> (screenshot, headline line 1, headline line 2, footer note)
FEATURES = [
    ("kundli",     "10 सेकंड में", "अपनी कुंडली बनाएं", "जन्म तिथि, समय और जगह — बस"),
    ("rashifal",   "आज का राशिफल", "शुभ रंग, अंक और दिशा", "चंद्र गोचर से, रोज़ सुबह"),
    ("gunmilan",   "शादी से पहले", "गुण मिलान करें", "36 गुण, दोष और मंगल विचार"),
    ("tarot",      "तारोट से पूछें", "आज का जवाब", "3 कार्ड — भूत, वर्तमान, भविष्य"),
    ("numerology", "मूलांक और भाग्यांक", "लो शू ग्रिड के साथ", "अंकों से अपना स्वभाव जानें"),
    ("dasha",      "अभी का समय", "कौन सी दशा चल रही है", "विंशोत्तरी दशा, विस्तार से"),
    ("reports",    "65 पेज की", "कुंडली रिपोर्ट", "800+ व्याख्या, घर बैठे"),
    ("golden",     "गोल्डन टाइम", "आपके सबसे शुभ दिन", "अगले 10 साल के शुभ समय"),
    ("muhurat",    "शुभ मुहूर्त", "ढूंढें एक क्लिक में", "विवाह, गृह प्रवेश, व्यापार"),
    ("sawal",      "हाँ या नहीं", "सवाल पूछें, जवाब पाएं", "रोज़ का सवाल — सही जवाब पर +2 तारा"),
    ("yogas",      "योग, दोष और", "लाल किताब ऋण", "मोहिनी योग से गंडांत तक"),
    ("lovemarriage","लव मैरिज के", "चांस कितने प्रतिशत", "D1 और D9 की 23 शर्तें"),
    ("nadi",       "नाड़ी प्रोग्रेशन", "आपकी जीवन यात्रा", "प्लैनेट प्रोग्रेशन चार्ट"),
    ("special",    "करियर के", "स्पेशल नियम", "शनि का दसवां भाव, गुरु का बल"),
    ("reviews",    "लोग क्या", "कहते हैं", "असली क्लाइंट के अनुभव"),
    ("explore",    "सब कुछ एक जगह", "सेव कुंडली, मुहूर्त, राशिफल", "आपका पूरा ज्योतिष डैशबोर्ड"),
    ("graha",      "ग्रह युद्ध", "आज कौन जीतेगा", "ग्रहों की टक्कर, सरल भाषा में"),
    ("beneficial", "आपके शुभ अंक", "2000 पॉइंट का हिसाब", "कौन सा अंक आपके लिए"),
]


def font(path, size):
    return ImageFont.truetype(path, size)


def wrap(text, fnt, max_w):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if fnt.getlength(t) <= max_w or not cur:
            cur = t
        else:
            lines.append(cur); cur = w
    if cur:
        lines.append(cur)
    return lines


def gradient():
    ys = [i / (H - 1) for i in range(H)]
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    for y in range(H):
        t = ys[y]
        c = tuple(int(BG1[i] * (1 - t) + BG2[i] * t) for i in range(3))
        d.line([(0, y), (W, y)], fill=c)
    return img.convert("RGBA")


def decor(img):
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    d.ellipse([W / 2 - 560, -260, W / 2 + 560, 860], fill=(255, 255, 255, 90))
    lay = lay.filter(ImageFilter.GaussianBlur(120))
    img.alpha_composite(lay)
    ring = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring)
    cx, cy, R = W // 2, 300, 300
    rd.ellipse([cx - R, cy - R, cx + R, cy + R], outline=GOLD + (40,), width=2)
    rd.ellipse([cx - R + 24, cy - R + 24, cx + R - 24, cy + R - 24], outline=GOLD + (26,), width=1)
    for k in range(12):
        a = math.pi * 2 * k / 12 - math.pi / 2
        rd.line([(cx + (R - 16) * math.cos(a), cy + (R - 16) * math.sin(a)),
                 (cx + (R + 16) * math.cos(a), cy + (R + 16) * math.sin(a))],
                fill=GOLD + (55,), width=2)
    img.alpha_composite(ring)
    return img


def phone_card(screen_path, box_w):
    scr = Image.open(screen_path).convert("RGB")
    ratio = scr.height / scr.width
    h = int(box_w * ratio)
    scr = scr.resize((box_w, h), Image.LANCZOS)
    pad = 10
    card = Image.new("RGBA", (box_w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    mask = Image.new("L", card.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, card.size[0] - 1, card.size[1] - 1], 38, fill=255)
    body = Image.new("RGBA", card.size, (255, 255, 255, 255))
    body.paste(scr, (pad, pad))
    card.paste(body, (0, 0), mask)
    return card, mask


def build_story(key, h1, h2, note, cfg, out_path):
    img = decor(gradient())
    d = ImageDraw.Draw(img)

    # brand
    fb = font(FONT_LAT, 30)
    brand = cfg.get("brand_line", "ADVANCED OCCULT ASTROLOGY").upper()
    d.text(((W - fb.getlength(brand)) / 2, 78), brand, font=fb, fill=BROWN + (235,))
    d.line([(W / 2 - 90, 128), (W / 2 + 90, 128)], fill=GOLD + (150,), width=2)

    # headline
    f1 = font(FONT_B, 82)
    l1 = wrap(h1, f1, 940)
    y = 200
    for ln in l1:
        d.text(((W - f1.getlength(ln)) / 2, y), ln, font=f1, fill=DEEP)
        y += int(82 * 1.22)
    f2 = font(FONT_B, 70)
    l2 = wrap(h2, f2, 940)
    for ln in l2:
        d.text(((W - f2.getlength(ln)) / 2, y), ln, font=f2, fill=GOLD)
        y += int(70 * 1.22)

    # phone card
    screen = os.path.join(SHOTS, key + ".jpg")
    if not os.path.exists(screen):
        raise SystemExit("missing screenshot: " + screen)
    box_w = 560
    card, mask = phone_card(screen, box_w)
    cx = (W - card.size[0]) // 2
    cy = max(y + 40, 640)
    if cy + card.size[1] > 1660:
        cy = 1660 - card.size[1]
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.rounded_rectangle([cx + 10, cy + 18, cx + card.size[0] + 10, cy + card.size[1] + 18],
                         38, fill=(60, 30, 10, 90))
    img.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(22)))
    img.paste(card, (cx, cy), mask)

    # footer CTA
    fc = font(FONT_B, 52)
    cta = cfg.get("website", {}).get("cta", "लिंक बायो में")
    d.rounded_rectangle([W / 2 - 330, 1712, W / 2 + 330, 1812], 50, fill=DEEP + (255,))
    d.text(((W - fc.getlength(cta)) / 2, 1730), cta, font=fc, fill=(250, 226, 176))
    fn = font(FONT_LAT, 26)
    dom = cfg.get("website", {}).get("domain", "advanced-occult-astrology.pages.dev")
    d.text(((W - fn.getlength(dom)) / 2, 1836), dom, font=fn, fill=BROWN + (190,))
    # note text is kept in FEATURES for future use; not drawn on the story

    img.convert("RGB").save(out_path, quality=92)
    return out_path


def pick_for_date(day):
    """3 different features per day, rotating so the same trio does not repeat soon."""
    idx = day.toordinal() * 3
    n = len(FEATURES)
    return [FEATURES[(idx + i) % n] for i in range(3)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", default=None)
    ap.add_argument("--outdir", default="/scratch/work/stories")
    ap.add_argument("--count", type=int, default=3)
    a = ap.parse_args()
    IST = timezone(timedelta(hours=5, minutes=30))
    day = datetime.fromisoformat(a.date).date() if a.date else datetime.now(IST).date()
    os.makedirs(a.outdir, exist_ok=True)
    cfg = json.load(open(os.path.join(HERE, "config.json"), encoding="utf-8"))

    picked = pick_for_date(day)[: a.count]
    made = []
    for i, (key, h1, h2, note) in enumerate(picked, 1):
        out = os.path.join(a.outdir, "story-%s-%s-%d.png" % (day.strftime("%Y%m%d"), key, i))
        build_story(key, h1, h2, note, cfg, out)
        made.append(out)
        print("STORY_OK", os.path.basename(out), os.path.getsize(out))
    print("TOTAL", len(made))


if __name__ == "__main__":
    main()
